ALTER TABLE public.products ADD COLUMN stock_quantity integer NOT NULL DEFAULT 0, ADD COLUMN cost_price numeric NOT NULL DEFAULT 0;
ALTER TABLE public.products ADD CONSTRAINT products_stock_nonnegative CHECK (stock_quantity >= 0), ADD CONSTRAINT products_cost_nonnegative CHECK (cost_price >= 0 AND cost_price <> 'NaN'::numeric);
ALTER TABLE public.orders ADD COLUMN completed_at timestamptz;
UPDATE public.orders SET completed_at = created_at WHERE status = 'Completed';
CREATE TABLE public.sales_items (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 order_id uuid NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
 product_id uuid NOT NULL,
 product_name text NOT NULL,
 quantity integer NOT NULL CHECK (quantity > 0),
 unit_price numeric NOT NULL,
 unit_cost numeric,
 revenue numeric NOT NULL,
 created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.sales_items TO authenticated;
GRANT ALL ON public.sales_items TO service_role;
ALTER TABLE public.sales_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admin read sales items" ON public.sales_items FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE INDEX sales_items_order_idx ON public.sales_items(order_id);
INSERT INTO public.sales_items(order_id, product_id, product_name, quantity, unit_price, unit_cost, revenue, created_at)
SELECT o.id, (i->>'product_id')::uuid, i->>'name', (i->>'quantity')::integer, (i->>'price')::numeric, NULL, (i->>'price')::numeric * (i->>'quantity')::integer, o.created_at
FROM public.orders o CROSS JOIN LATERAL jsonb_array_elements(o.items) i;
REVOKE SELECT ON public.products FROM anon, authenticated;
GRANT SELECT(id, name, description, category, price, image_url, images, sizes, featured, created_at, stock_quantity) ON public.products TO anon, authenticated;
CREATE OR REPLACE FUNCTION public.admin_inventory()
RETURNS SETOF public.products LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
 IF NOT public.has_role(auth.uid(), 'admin') THEN RAISE EXCEPTION 'Admin access required'; END IF;
 RETURN QUERY SELECT * FROM public.products ORDER BY created_at DESC;
END; $$;
REVOKE ALL ON FUNCTION public.admin_inventory() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.admin_inventory() TO authenticated;
CREATE OR REPLACE FUNCTION public.track_order_completion()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
 IF NEW.status = 'Completed' THEN
   IF TG_OP = 'INSERT' THEN NEW.completed_at := now();
   ELSIF OLD.status <> 'Completed' THEN NEW.completed_at := now();
   ELSE NEW.completed_at := OLD.completed_at;
   END IF;
 ELSE NEW.completed_at := NULL;
 END IF;
 RETURN NEW;
END; $$;
CREATE TRIGGER orders_completion_timestamp BEFORE INSERT OR UPDATE ON public.orders FOR EACH ROW EXECUTE FUNCTION public.track_order_completion();
CREATE OR REPLACE FUNCTION public.place_order(_full_name text, _email text, _phone text, _address text, _items jsonb)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _out jsonb := '[]'::jsonb; _total numeric := 0; _it jsonb; _p record; _qty integer; _id uuid;
BEGIN
 IF _full_name IS NULL OR length(trim(_full_name)) = 0 OR length(_full_name) > 120 THEN RAISE EXCEPTION 'Invalid name'; END IF;
 IF _email IS NULL OR _email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' OR length(_email) > 255 THEN RAISE EXCEPTION 'Invalid email'; END IF;
 IF _phone IS NULL OR length(trim(_phone)) < 5 OR length(_phone) > 30 THEN RAISE EXCEPTION 'Invalid phone'; END IF;
 IF _address IS NULL OR length(trim(_address)) < 5 OR length(_address) > 500 THEN RAISE EXCEPTION 'Invalid address'; END IF;
 IF _items IS NULL OR jsonb_typeof(_items) <> 'array' THEN RAISE EXCEPTION 'Invalid items'; END IF;
 IF jsonb_array_length(_items) = 0 OR jsonb_array_length(_items) > 50 THEN RAISE EXCEPTION 'Invalid items'; END IF;
 PERFORM p.id FROM public.products p WHERE p.id IN (SELECT (i->>'product_id')::uuid FROM jsonb_array_elements(_items) i) ORDER BY p.id FOR UPDATE;
 FOR _it IN SELECT * FROM jsonb_array_elements(_items) LOOP
   SELECT id,name,price,cost_price,stock_quantity INTO _p FROM public.products WHERE id = (_it->>'product_id')::uuid;
   IF NOT FOUND THEN RAISE EXCEPTION 'Product not found'; END IF;
   _qty := (_it->>'quantity')::integer;
   IF _qty IS NULL OR _qty < 1 OR _qty > 99 THEN RAISE EXCEPTION 'Invalid quantity'; END IF;
   IF _p.stock_quantity < _qty THEN RAISE EXCEPTION 'Insufficient stock for %', _p.name; END IF;
   UPDATE public.products SET stock_quantity = stock_quantity - _qty WHERE id = _p.id;
   _total := _total + _p.price * _qty;
   _out := _out || jsonb_build_object('product_id', _p.id, 'name', _p.name, 'price', _p.price, 'cost_price', _p.cost_price, 'quantity', _qty, 'size', left(coalesce(_it->>'size',''),20), 'measurements', left(coalesce(_it->>'measurements',''),500));
 END LOOP;
 INSERT INTO public.orders(full_name,email,phone,address,items,total) VALUES(trim(_full_name),trim(_email),trim(_phone),trim(_address),_out,_total) RETURNING id INTO _id;
 INSERT INTO public.sales_items(order_id, product_id, product_name, quantity, unit_price, unit_cost, revenue)
 SELECT _id, (i->>'product_id')::uuid, i->>'name', (i->>'quantity')::integer, (i->>'price')::numeric, (i->>'cost_price')::numeric, (i->>'price')::numeric * (i->>'quantity')::integer FROM jsonb_array_elements(_out) i;
 RETURN _id;
END; $$;
REVOKE ALL ON FUNCTION public.place_order(text,text,text,text,jsonb) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.place_order(text,text,text,text,jsonb) TO anon, authenticated;
COMMENT ON COLUMN public.products.cost_price IS 'Admin-only production cost; public product reads must use the explicit public column list.';
COMMENT ON COLUMN public.orders.completed_at IS 'Completion time; legacy completed orders use order creation date because historical completion time was not recorded.';
COMMENT ON COLUMN public.sales_items.unit_cost IS 'Historical checkout cost snapshot; NULL for legacy sales whose production costs were not recorded.';