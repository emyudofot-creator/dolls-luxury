ALTER TABLE public.products ADD COLUMN images text[] NOT NULL DEFAULT '{}';
UPDATE public.products SET images = ARRAY[image_url] WHERE image_url IS NOT NULL AND image_url <> '';