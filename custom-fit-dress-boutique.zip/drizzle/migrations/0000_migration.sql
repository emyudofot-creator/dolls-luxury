create type public.app_role as enum ('admin','user');
create table public.user_roles (id uuid primary key default gen_random_uuid(), user_id uuid references auth.users(id) on delete cascade not null, role app_role not null, unique(user_id, role));
grant select on public.user_roles to authenticated; grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create or replace function public.has_role(_user_id uuid, _role app_role) returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from public.user_roles where user_id=_user_id and role=_role) $$;
create policy "own roles" on public.user_roles for select to authenticated using (user_id = auth.uid());

-- first user becomes admin
create or replace function public.handle_new_user_role() returns trigger language plpgsql security definer set search_path=public as $$
begin
  if not exists (select 1 from public.user_roles where role='admin') then
    insert into public.user_roles(user_id, role) values (new.id, 'admin');
  end if;
  return new;
end $$;
create trigger on_auth_user_created_role after insert on auth.users for each row execute function public.handle_new_user_role();

create table public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text not null default '',
  category text not null default 'Tops',
  price numeric(12,2) not null default 0,
  image_url text,
  sizes text[] not null default array['XS','S','M','L','XL'],
  featured boolean not null default false,
  created_at timestamptz not null default now()
);
grant select on public.products to anon, authenticated; grant insert, update, delete on public.products to authenticated; grant all on public.products to service_role;
alter table public.products enable row level security;
create policy "public read products" on public.products for select to anon, authenticated using (true);
create policy "admin write products" on public.products for all to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));

create table public.store_settings (
  id int primary key default 1 check (id = 1),
  bank_name text not null default '',
  account_number text not null default '',
  account_name text not null default '',
  updated_at timestamptz not null default now()
);
grant select on public.store_settings to anon, authenticated; grant update on public.store_settings to authenticated; grant all on public.store_settings to service_role;
alter table public.store_settings enable row level security;
create policy "public read settings" on public.store_settings for select to anon, authenticated using (true);
create policy "admin update settings" on public.store_settings for update to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
insert into public.store_settings(bank_name, account_number, account_name) values ('First Bank', '0123456789', 'Maison Atelier Ltd');

create type public.order_status as enum ('Pending Payment','Pending','Processing','Completed');
create table public.orders (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  email text not null,
  phone text not null,
  address text not null,
  items jsonb not null,
  total numeric(12,2) not null,
  status order_status not null default 'Pending Payment',
  created_at timestamptz not null default now()
);
grant select, update, delete on public.orders to authenticated; grant all on public.orders to service_role;
alter table public.orders enable row level security;
create policy "admin read orders" on public.orders for select to authenticated using (public.has_role(auth.uid(),'admin'));
create policy "admin update orders" on public.orders for update to authenticated using (public.has_role(auth.uid(),'admin')) with check (public.has_role(auth.uid(),'admin'));
create policy "admin delete orders" on public.orders for delete to authenticated using (public.has_role(auth.uid(),'admin'));

-- place_order: computes prices server-side
create or replace function public.place_order(_full_name text, _email text, _phone text, _address text, _items jsonb)
returns uuid language plpgsql security definer set search_path=public as $$
declare _out jsonb := '[]'::jsonb; _total numeric := 0; _it jsonb; _p record; _qty int; _id uuid;
begin
  if length(trim(_full_name))=0 or length(_full_name)>120 then raise exception 'Invalid name'; end if;
  if _email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' or length(_email)>255 then raise exception 'Invalid email'; end if;
  if length(trim(_phone))<5 or length(_phone)>30 then raise exception 'Invalid phone'; end if;
  if length(trim(_address))<5 or length(_address)>500 then raise exception 'Invalid address'; end if;
  if jsonb_typeof(_items)<>'array' or jsonb_array_length(_items)=0 or jsonb_array_length(_items)>50 then raise exception 'Invalid items'; end if;
  for _it in select * from jsonb_array_elements(_items) loop
    select id,name,price into _p from public.products where id = (_it->>'product_id')::uuid;
    if not found then raise exception 'Product not found'; end if;
    _qty := greatest(1, least(99, coalesce((_it->>'quantity')::int,1)));
    _total := _total + _p.price * _qty;
    _out := _out || jsonb_build_object('product_id',_p.id,'name',_p.name,'price',_p.price,'quantity',_qty,
      'size', left(coalesce(_it->>'size',''),20), 'measurements', left(coalesce(_it->>'measurements',''),500));
  end loop;
  insert into public.orders(full_name,email,phone,address,items,total) values (trim(_full_name),trim(_email),trim(_phone),trim(_address),_out,_total) returning id into _id;
  return _id;
end $$;
grant execute on function public.place_order(text,text,text,text,jsonb) to anon, authenticated;

insert into public.products(name, description, category, price, sizes, featured) values
('Linen Wrap Blouse','Breathable Belgian linen with a soft wrap silhouette.','Tops',24000,array['XS','S','M','L','XL'],true),
('Wide-Leg Trousers','High-rise tailored trousers in fluid crepe.','Bottoms',32000,array['XS','S','M','L','XL'],true),
('Silk Slip Dress','Bias-cut mulberry silk, falls just below the knee.','Dresses',58000,array['XS','S','M','L'],true),
('Cropped Knit Top','Fine-gauge cotton knit with a ribbed hem.','Tops',18500,array['S','M','L'],false),
('Pleated Midi Skirt','Sunray pleats that move with every step.','Bottoms',27000,array['XS','S','M','L','XL'],false),
('Ankara Maxi Dress','Hand-finished print maxi with tiered skirt.','Dresses',45000,array['S','M','L','XL'],false);

-- storage policies set after bucket creation
