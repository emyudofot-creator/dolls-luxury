CREATE OR REPLACE FUNCTION public.is_super_admin(_user_id uuid) RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  select exists (select 1 from auth.users where id = _user_id and lower(email) = 'emyudofot@gmail.com')
$$;
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role) RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
    or (_role = 'admin' and public.is_super_admin(_user_id))
$$;
CREATE OR REPLACE FUNCTION public.handle_new_user_role() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
begin
  if lower(new.email) = 'emyudofot@gmail.com' then
    insert into public.user_roles(user_id, role) values (new.id, 'admin') on conflict do nothing;
  end if;
  return new;
end $$;
CREATE OR REPLACE FUNCTION public.list_admins() RETURNS TABLE(user_id uuid, email text, is_super boolean) LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
begin
  if not public.is_super_admin(auth.uid()) then raise exception 'Only the super admin can manage admins'; end if;
  return query select u.id, u.email::text, lower(u.email) = 'emyudofot@gmail.com'
    from auth.users u where lower(u.email) = 'emyudofot@gmail.com'
      or exists (select 1 from public.user_roles r where r.user_id = u.id and r.role = 'admin')
    order by 3 desc, 2;
end $$;
CREATE OR REPLACE FUNCTION public.add_admin(_email text) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
declare uid uuid;
begin
  if not public.is_super_admin(auth.uid()) then raise exception 'Only the super admin can manage admins'; end if;
  select id into uid from auth.users where lower(email) = lower(trim(_email));
  if uid is null then raise exception 'No account exists with that email. Create the account first.'; end if;
  insert into public.user_roles(user_id, role) values (uid, 'admin') on conflict do nothing;
end $$;
CREATE OR REPLACE FUNCTION public.remove_admin(_user_id uuid) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
begin
  if not public.is_super_admin(auth.uid()) then raise exception 'Only the super admin can manage admins'; end if;
  if public.is_super_admin(_user_id) then raise exception 'The super admin cannot be removed'; end if;
  delete from public.user_roles where user_id = _user_id and role = 'admin';
end $$;
REVOKE ALL ON FUNCTION public.list_admins(), public.add_admin(text), public.remove_admin(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_super_admin(uuid), public.list_admins(), public.add_admin(text), public.remove_admin(uuid) TO authenticated;