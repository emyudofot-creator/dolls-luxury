CREATE TABLE public.delivery_zones (
  id text PRIMARY KEY,
  name text NOT NULL,
  states text[] NOT NULL DEFAULT '{}',
  fee numeric NOT NULL DEFAULT 0 CHECK (fee >= 0),
  sort_order integer NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.delivery_zones TO anon, authenticated;
GRANT UPDATE ON public.delivery_zones TO authenticated;
GRANT ALL ON public.delivery_zones TO service_role;
ALTER TABLE public.delivery_zones ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read zones" ON public.delivery_zones FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "admin update zones" ON public.delivery_zones FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

ALTER TABLE public.orders ADD COLUMN stockpile boolean NOT NULL DEFAULT false;
ALTER TABLE public.orders ADD COLUMN shipping_state text;
ALTER TABLE public.orders ADD COLUMN delivery_fee numeric NOT NULL DEFAULT 0;
ALTER TABLE public.orders ADD COLUMN subtotal numeric;
UPDATE public.orders SET subtotal = total WHERE subtotal IS NULL;

CREATE OR REPLACE FUNCTION public.place_order(_full_name text, _email text, _phone text, _address text, _items jsonb, _stockpile boolean, _state text)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _out jsonb := '[]'::jsonb; _total numeric := 0; _it jsonb; _p record; _qty integer; _id uuid; _fee numeric := 0;
BEGIN
 IF _full_name IS NULL OR length(trim(_full_name)) = 0 OR length(_full_name) > 120 THEN RAISE EXCEPTION 'Invalid name'; END IF;
 IF _email IS NULL OR _email !~ '^[^@\s]+@[^@\s]+\.[^@\s]+$' OR length(_email) > 255 THEN RAISE EXCEPTION 'Invalid email'; END IF;
 IF _phone IS NULL OR length(trim(_phone)) < 5 OR length(_phone) > 30 THEN RAISE EXCEPTION 'Invalid phone'; END IF;
 IF _address IS NULL OR length(trim(_address)) < 5 OR length(_address) > 500 THEN RAISE EXCEPTION 'Invalid address'; END IF;
 IF _items IS NULL OR jsonb_typeof(_items) <> 'array' THEN RAISE EXCEPTION 'Invalid items'; END IF;
 IF jsonb_array_length(_items) = 0 OR jsonb_array_length(_items) > 50 THEN RAISE EXCEPTION 'Invalid items'; END IF;
 IF NOT coalesce(_stockpile,false) THEN
   SELECT fee INTO _fee FROM public.delivery_zones WHERE _state = ANY(states) LIMIT 1;
   IF NOT FOUND THEN RAISE EXCEPTION 'Please select a delivery state'; END IF;
 END IF;
 PERFORM p.id FROM public.products p WHERE p.id IN (SELECT (i->>'product_id')::uuid FROM jsonb_array_elements(_items) i) ORDER BY p.id FOR UPDATE;
 FOR _it IN SELECT * FROM jsonb_array_elements(_items) LOOP
   SELECT id,name,price,cost_price,stock_quantity INTO _p FROM public.products WHERE id = (_it->>'product_id')::uuid;
   IF NOT FOUND THEN RAISE EXCEPTION 'Product not found'; END IF;
   _qty := (_it->>'quantity')::integer;
   IF _qty IS NULL OR _qty < 1 OR _qty > 99 THEN RAISE EXCEPTION 'Invalid quantity'; END IF;
   IF _p.stock_quantity < _qty THEN RAISE EXCEPTION 'Insufficient stock for %', _p.name; END IF;
   UPDATE public.products SET stock_quantity = stock_quantity - _qty WHERE id = _p.id;
   _total := _total + _p.price * _qty;
   _out := _out || jsonb_build_object('product_id', _p.id, 'name', _p.name, 'price', _p.price, 'cost_price', _p.cost_price, 'quantity', _qty, 'size', left(coalesce(_it->>'size',''),20), 'measurements', left(coalesce(_it->>'measurements',''),500));
 END LOOP;
 INSERT INTO public.orders(full_name,email,phone,address,items,subtotal,delivery_fee,total,stockpile,shipping_state)
 VALUES(trim(_full_name),trim(_email),trim(_phone),trim(_address),_out,_total,coalesce(_fee,0),_total+coalesce(_fee,0),coalesce(_stockpile,false),CASE WHEN coalesce(_stockpile,false) THEN NULL ELSE _state END) RETURNING id INTO _id;
 INSERT INTO public.sales_items(order_id, product_id, product_name, quantity, unit_price, unit_cost, revenue)
 SELECT _id, (i->>'product_id')::uuid, i->>'name', (i->>'quantity')::integer, (i->>'price')::numeric, (i->>'cost_price')::numeric, (i->>'price')::numeric * (i->>'quantity')::integer FROM jsonb_array_elements(_out) i;
 RETURN _id;
END; $$;
REVOKE ALL ON FUNCTION public.place_order(text,text,text,text,jsonb,boolean,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.place_order(text,text,text,text,jsonb,boolean,text) TO anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.place_order(text,text,text,text,jsonb) FROM anon, authenticated;
COMMENT ON FUNCTION public.place_order(text,text,text,text,jsonb) IS 'DEPRECATED: replaced by place_order with stockpile and delivery state';