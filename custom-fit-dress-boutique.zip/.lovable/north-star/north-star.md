# North star

Shoppers get luxury outfits they love to wear.

## Metric

Orders placed at checkout each week
