import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";

const WHATSAPP_URL = "https://wa.me/2348162015314";

/**
 * Fixed customer-service launcher. Sits above the storefront while scrolling and
 * stays under dialogs (z-30) so the bag sheet covers it when open.
 */
export function WhatsAppFloat() {
  const [mounted, setMounted] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => setMounted(true), []);

  return (
    <div
      className={cn(
        "group fixed bottom-5 right-5 z-30 flex flex-col items-end transition-all duration-500 ease-out sm:bottom-8 sm:right-8",
        mounted ? "translate-y-0 opacity-100" : "translate-y-6 opacity-0",
      )}
    >
      <div
        className={cn(
          "relative mb-3 w-64 origin-bottom-right rounded-md border bg-card p-4 text-card-foreground shadow-xl transition-all duration-300 ease-out",
          open
            ? "pointer-events-auto translate-y-0 scale-100 opacity-100"
            : "pointer-events-none translate-y-2 scale-95 opacity-0 group-hover:pointer-events-auto group-hover:translate-y-0 group-hover:scale-100 group-hover:opacity-100 group-focus-within:pointer-events-auto group-focus-within:translate-y-0 group-focus-within:scale-100 group-focus-within:opacity-100",
        )}
      >
        <p className="font-display text-lg leading-snug">Hi! How can we help you today?</p>
        <p className="mt-1 text-xs text-muted-foreground">Chat with Customer Service on WhatsApp.</p>
        <span aria-hidden className="absolute -bottom-[5px] right-7 h-2.5 w-2.5 rotate-45 border-b border-r bg-card" />
      </div>

      <a
        href={WHATSAPP_URL}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat with Customer Service on WhatsApp"
        onClick={() => setOpen((v) => !v)}
        className="relative flex h-14 w-14 items-center justify-center rounded-full bg-whatsapp text-whatsapp-foreground shadow-lg transition duration-300 hover:scale-105 hover:shadow-xl focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-whatsapp"
      >
        <span aria-hidden className="absolute inset-0 rounded-full bg-whatsapp opacity-0 blur-md transition-opacity duration-500 group-hover:opacity-40" />
        <svg viewBox="0 0 448 512" aria-hidden className="relative h-7 w-7 fill-current">
          <path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.7z" />
        </svg>
      </a>
    </div>
  );
}
