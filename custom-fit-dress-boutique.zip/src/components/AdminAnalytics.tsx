import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { inventoryQuery, ordersQuery, salesQuery } from "@/lib/admin-data";
import { inventoryAnalytics } from "@/lib/analytics";
import { formatPrice } from "@/lib/store";

export function AdminMetrics() {
  const inventory = useQuery(inventoryQuery);
  const orders = useQuery(ordersQuery);
  const sales = useQuery(salesQuery);
  if (inventory.isError || orders.isError || sales.isError) return <p role="alert" className="mb-8 text-destructive">Unable to load inventory and sales totals.</p>;
  const loading = inventory.isPending || orders.isPending || sales.isPending;
  const values = inventoryAnalytics(inventory.data ?? [], orders.data ?? [], sales.data ?? []);
  return <section aria-label="Inventory and sales totals" className="mb-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
    {[
      { label: "Total Cost of Available Inventory", value: values.inventoryCost },
      { label: "Total Revenue Sold", value: values.revenue },
      { label: "Gross Profit", value: values.profit },
    ].map((metric) => <div key={metric.label} className="min-w-0 border bg-card p-5">
      <h2 className="text-sm text-muted-foreground">{metric.label}</h2>
      <p className="mt-3 break-words font-display text-3xl">{loading ? "…" : metric.value === null ? "Unavailable" : formatPrice(metric.value)}</p>
      {metric.label === "Gross Profit" && <p className="mt-2 text-xs text-muted-foreground">{values.cost === null ? "Earlier sales have no recorded cost." : `Cost of goods sold: ${formatPrice(values.cost)}`} · Before expenses</p>}
    </div>)}
  </section>;
}

export const SALES_FILTERS = ["Completed sales", "Stockpiled orders", "Needs shipping"] as const;
type SalesFilter = (typeof SALES_FILTERS)[number];
type OrderRow = { status: string; stockpile: boolean };
/** Completed = recognised sales; Stockpiled = held items (any status); Needs shipping = regular orders not yet completed. */
export const filterSales = <T extends OrderRow>(orders: T[], f: SalesFilter) =>
  orders.filter((o) => f === "Completed sales" ? o.status === "Completed" : f === "Stockpiled orders" ? o.stockpile : !o.stockpile && o.status !== "Completed");

export function RecentSales() {
  const { data: orders = [], isPending, isError } = useQuery(ordersQuery);
  const [filter, setFilter] = useState<SalesFilter>("Completed sales");
  const rows = filterSales(orders, filter).sort((a, b) => new Date(b.completed_at ?? b.created_at).getTime() - new Date(a.completed_at ?? a.created_at).getTime()).slice(0, 50);
  return <section className="mt-12 border-t pt-8">
    <h2 className="text-3xl">Recent Sales History</h2>
    <div role="tablist" className="mt-4 flex flex-wrap gap-2">
      {SALES_FILTERS.map((f) => <button key={f} role="tab" aria-selected={filter === f} onClick={() => setFilter(f)} className={`border px-4 py-2 text-xs uppercase tracking-widest ${filter === f ? "bg-primary text-primary-foreground" : "bg-card"}`}>{f}</button>)}
    </div>
    {isError ? <p role="alert" className="mt-4 text-destructive">Unable to load sales history.</p> : isPending ? <p className="mt-4 text-sm">Loading…</p> : !rows.length ? <p className="mt-4 text-sm text-muted-foreground">No orders here yet.</p> : <div className="mt-5 overflow-x-auto">
      <table className="w-full text-left text-sm">
        <thead className="border-b text-muted-foreground"><tr><th className="py-3 pr-5 font-normal">Order</th><th className="py-3 pr-5 font-normal">Customer</th><th className="py-3 pr-5 font-normal">Delivery</th><th className="py-3 pr-5 font-normal">Status</th><th className="py-3 pr-5 font-normal">Date</th><th className="py-3 text-right font-normal">Order value</th></tr></thead>
        <tbody>{rows.map((o) => <tr key={o.id} className="border-b"><td className="whitespace-nowrap py-4 pr-5">#{o.id.slice(0, 8)}</td><td className="py-4 pr-5">{o.full_name}<span className="block text-xs text-muted-foreground">{o.phone}</span></td><td className="py-4 pr-5">{o.stockpile ? "Stockpile: True" : o.shipping_state ?? "—"}</td><td className="py-4 pr-5">{o.status}</td><td className="whitespace-nowrap py-4 pr-5">{new Date(o.completed_at ?? o.created_at).toLocaleDateString("en-NG")}</td><td className="whitespace-nowrap py-4 text-right">{formatPrice(o.total)}</td></tr>)}</tbody>
      </table>
    </div>}
  </section>;
}
