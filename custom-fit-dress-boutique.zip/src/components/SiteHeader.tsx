import { Link } from "@tanstack/react-router";
import { ShoppingBag, Minus, Plus, X } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { useCart } from "@/lib/cart";
import { BRAND, formatPrice } from "@/lib/store";

export function SiteHeader() {
  const { count, setOpen } = useCart();
  return (
    <header className="sticky top-0 z-40 border-b bg-background/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
        <nav className="hidden gap-8 text-xs uppercase tracking-[0.2em] md:flex">
          <Link to="/" className="hover:text-blush">Shop</Link>
          <a href="/#collection" className="hover:text-blush">Collection</a>
        </nav>
        <Link to="/" className="font-display text-3xl tracking-tight">{BRAND}</Link>
        <button onClick={() => setOpen(true)} className="relative flex items-center gap-2 text-xs uppercase tracking-[0.2em]" aria-label="Open cart">
          <ShoppingBag className="h-5 w-5" strokeWidth={1.4} />
          <span className="hidden sm:inline">Bag</span>
          {count > 0 && (
            <span className="absolute -right-2 -top-2 flex h-5 w-5 items-center justify-center rounded-full bg-blush text-[10px] text-primary-foreground">{count}</span>
          )}
        </button>
      </div>
      <CartSheet />
    </header>
  );
}

function CartSheet() {
  const { items, open, setOpen, setQty, remove, total } = useCart();
  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetContent className="flex w-full flex-col sm:max-w-md">
        <SheetHeader>
          <SheetTitle className="font-display text-2xl font-normal">Your Bag</SheetTitle>
        </SheetHeader>
        <div className="flex-1 space-y-6 overflow-y-auto px-4">
          {items.length === 0 && <p className="py-12 text-center text-sm text-muted-foreground">Your bag is empty.</p>}
          {items.map((i) => (
            <div key={i.key} className="flex gap-4">
              <img src={i.image} alt={i.name} loading="lazy" decoding="async" width={80} height={112} className="h-28 w-20 object-cover" />
              <div className="flex flex-1 flex-col">
                <div className="flex justify-between">
                  <p className="font-display text-lg">{i.name}</p>
                  <button onClick={() => remove(i.key)} aria-label="Remove"><X className="h-4 w-4 text-muted-foreground" /></button>
                </div>
                <p className="text-xs text-muted-foreground">Size: {i.size}{i.measurements && " · Custom"}</p>
                <p className="text-xs text-muted-foreground">{formatPrice(i.price)} each</p>
                <div className="mt-auto flex items-center justify-between">
                  <div className="flex items-center border">
                    <button className="p-1.5" onClick={() => setQty(i.key, i.quantity - 1)} aria-label="Decrease"><Minus className="h-3 w-3" /></button>
                    <span className="w-8 text-center text-sm">{i.quantity}</span>
                    <button className="p-1.5" onClick={() => setQty(i.key, i.quantity + 1)} aria-label="Increase"><Plus className="h-3 w-3" /></button>
                  </div>
                  <span className="text-sm">{formatPrice(i.price * i.quantity)}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="space-y-4 border-t p-4">
          <div className="flex justify-between text-sm uppercase tracking-widest">
            <span>Total</span><span>{formatPrice(total)}</span>
          </div>
          <Button asChild size="lg" className="w-full rounded-none uppercase tracking-[0.2em]" disabled={!items.length}>
            <Link to="/checkout" onClick={() => setOpen(false)}>Checkout</Link>
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}

export function SiteFooter() {
  return (
    <footer className="mt-24 border-t">
      <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-6 py-10 text-xs text-muted-foreground sm:flex-row">
        <span className="font-display text-xl text-foreground">{BRAND}</span>
        <span>© {new Date().getFullYear()} {BRAND}. Made with care.</span>
      </div>
    </footer>
  );
}
