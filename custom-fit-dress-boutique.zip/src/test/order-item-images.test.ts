import { describe, expect, it } from "vitest";
import { productImageMap } from "@/lib/admin-data";

describe("Order item thumbnails", () => {
  it("uses the first uploaded photo when a product has several", () => {
    const images = productImageMap([
      { id: "p1", image_url: "legacy.jpg", images: ["first.jpg", "second.jpg"] },
    ]);
    expect(images.get("p1")).toBe("first.jpg");
  });

  it("falls back to the single legacy image when no photos were uploaded", () => {
    const images = productImageMap([{ id: "p2", image_url: "legacy.jpg", images: [] }]);
    expect(images.get("p2")).toBe("legacy.jpg");
  });

  it("returns no photo for a product without any image, so a placeholder shows", () => {
    const images = productImageMap([{ id: "p3", image_url: null, images: [] }]);
    expect(images.get("p3")).toBeNull();
  });

  it("returns no photo for an ordered product that has since been deleted", () => {
    const images = productImageMap([{ id: "p4", image_url: "kept.jpg", images: [] }]);
    expect(images.get("gone")).toBeUndefined();
  });
});
