import { describe, expect, it } from "vitest";
import { inventoryAnalytics } from "@/lib/analytics";

describe("Inventory and completed sales accounting", () => {
  it("sums production cost times remaining stock", () => {
    expect(inventoryAnalytics([{ cost_price: 12000, stock_quantity: 3 }, { cost_price: 8000, stock_quantity: 2 }], [], []).inventoryCost).toBe(52000);
  });
  it("recognizes only completed transaction totals", () => {
    expect(inventoryAnalytics([], [{ id: "paid", status: "Completed", total: 48000 }, { id: "pending", status: "Pending Payment", total: 24000 }], []).revenue).toBe(48000);
  });
  it("uses checkout cost snapshots rather than current production costs", () => {
    const result = inventoryAnalytics([{ cost_price: 20000, stock_quantity: 3 }], [{ id: "paid", status: "Completed", total: 48000 }], [{ order_id: "paid", quantity: 2, unit_cost: 12000, revenue: 48000 }]);
    expect(result.cost).toBe(24000);
    expect(result.profit).toBe(24000);
  });
  it("does not invent costs or profit for legacy completed sales", () => {
    expect(inventoryAnalytics([], [{ id: "old", status: "Completed", total: 24000 }], [{ order_id: "old", quantity: 1, unit_cost: null, revenue: 24000 }]).profit).toBeNull();
  });
});