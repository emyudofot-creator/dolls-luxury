import { describe, it, expect, vi } from "vitest";
vi.mock("@/integrations/supabase/client", () => ({ supabase: {} }));
import { deliveryFee, type DeliveryZone } from "@/lib/store";
import { filterSales } from "@/components/AdminAnalytics";

const zones: DeliveryZone[] = [
  { id: "southwest", name: "Lagos / Southwest", states: ["Lagos", "Ogun"], fee: 4000, sort_order: 1 },
  { id: "uyo", name: "Uyo, Eket, Abak & Oron (Akwa Ibom)", states: ["Uyo", "Eket", "Abak", "Oron"], fee: 2000, sort_order: 2 },
  { id: "north", name: "Abuja & North", states: ["FCT Abuja", "Kano"], fee: 5500, sort_order: 5 },
];
describe("delivery fees", () => {
  it("charges the region fee for the chosen state", () => expect(deliveryFee(zones, "Kano", false)).toBe(5500));
  it("Lagos and Southwest share one fee", () => expect(deliveryFee(zones, "Lagos", false)).toBe(deliveryFee(zones, "Ogun", false)));
  it("Uyo, Eket, Abak and Oron all pay the same Akwa Ibom fee", () => {
    for (const town of ["Uyo", "Eket", "Abak", "Oron"]) {
      expect(deliveryFee(zones, town, false)).toBe(2000);
    }
  });
  it("stockpiling makes shipping free", () => expect(deliveryFee(zones, "Lagos", true)).toBe(0));
});
describe("sales filters", () => {
  const orders = [
    { id: "a", status: "Completed", stockpile: false },
    { id: "b", status: "Pending Payment", stockpile: true },
    { id: "c", status: "Processing", stockpile: false },
  ];
  it("stockpiled tab shows only held orders", () => expect(filterSales(orders, "Stockpiled orders").map((o) => o.id)).toEqual(["b"]));
  it("needs shipping shows open regular orders", () => expect(filterSales(orders, "Needs shipping").map((o) => o.id)).toEqual(["c"]));
});
