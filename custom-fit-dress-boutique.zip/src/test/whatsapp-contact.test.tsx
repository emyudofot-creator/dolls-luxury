import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";

import { WhatsAppFloat } from "@/components/WhatsAppFloat";

describe("WhatsApp customer service launcher", () => {
  it("opens the shop's WhatsApp chat in a new tab", () => {
    render(<WhatsAppFloat />);

    const link = screen.getByRole("link", { name: "Chat with Customer Service on WhatsApp" });

    expect(link).toHaveAttribute("href", "https://wa.me/2348162015314");
    expect(link).toHaveAttribute("target", "_blank");
    expect(link).toHaveAttribute("rel", "noopener noreferrer");
  });
});
