import asyncio,json,os
from pathlib import Path
from playwright.async_api import async_playwright

async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(headless=True); context=await browser.new_context(viewport={'width':1280,'height':1800}); page=await context.new_page()
  await page.goto('http://localhost:8080'); await page.evaluate('([k,v])=>localStorage.setItem(k,v)',[os.environ['LOVABLE_BROWSER_SUPABASE_STORAGE_KEY'],os.environ['LOVABLE_BROWSER_SUPABASE_SESSION_JSON']]); await page.goto('http://localhost:8080/admin'); await page.get_by_role('button',name='Add outfit').wait_for()
  result=await page.evaluate('''async () => {
    const {supabase} = await import('/src/integrations/supabase/client.ts');
    const {data:p,error:e}=await supabase.from('products').insert({name:'Stock rules verification',price:24000,cost_price:12000,stock_quantity:1}).select('id').single();
    if(e) throw Error(e.message);
    const args={_full_name:'Stock Rules Verification',_email:'stock-rules@example.invalid',_phone:'08000000000',_address:'Verification only - not a real delivery',_items:[{product_id:p.id,quantity:1,size:'S'},{product_id:p.id,quantity:1,size:'M'}]};
    try {
      const duplicate=await supabase.rpc('place_order',args);
      const {data:stock}=await supabase.from('products').select('stock_quantity').eq('id',p.id).single();
      const results=await Promise.all([supabase.rpc('place_order',{...args,_items:[args._items[0]]}),supabase.rpc('place_order',{...args,_items:[args._items[0]]})]);
      const {data:after}=await supabase.from('products').select('stock_quantity').eq('id',p.id).single();
      const {data:lines}=await supabase.from('sales_items').select('unit_cost,quantity,revenue').eq('product_id',p.id);
      return {duplicateRejected:!!duplicate.error,rollbackStock:stock.stock_quantity,successfulConcurrentOrders:results.filter(r=>!r.error).length,remainingStock:after.stock_quantity,lines};
    } finally { await supabase.from('orders').delete().eq('email','stock-rules@example.invalid'); await supabase.from('products').delete().eq('id',p.id); }
  }''')
  assert result['duplicateRejected'] and result['rollbackStock']==1
  # Pending orders do not reserve stock; deduction happens on admin approval
  assert result['successfulConcurrentOrders']==2 and result['remainingStock']==1
  assert result['lines']==[{'unit_cost':12000,'quantity':1,'revenue':24000}]
  print('Database rules passed:',result)
  await browser.close()
asyncio.run(main())
