import { describe, expect, it } from "vitest";

import { CATEGORIES, defaultSizes, displaySizes, filterProducts, type Product } from "@/lib/store";

const item = (name: string, category: string): Product => ({
  id: name,
  name,
  description: "",
  category,
  price: 0,
  image_url: null,
  images: [],
  sizes: [],
  featured: false,
  stock_quantity: 0,
});

const stock = [item("Linen Wrap Blouse", "Tops"), item("Silk Slip Dress", "Dresses"), item("Co-ord Set", "Two Piece")];

describe("Storefront categories", () => {
  it("offers Two Piece alongside the original categories", () => {
    expect(CATEGORIES).toEqual(["Tops", "Bottoms", "Dresses", "Two Piece", "Bags", "Shoes"]);
  });

  it("shows only two-piece outfits when that filter is active", () => {
    expect(filterProducts(stock, "Two Piece", "").map((p) => p.name)).toEqual(["Co-ord Set"]);
  });

  it("shows every outfit under All and still narrows by search", () => {
    expect(filterProducts(stock, "All", "")).toHaveLength(3);
    expect(filterProducts(stock, "Two Piece", "silk").map((p) => p.name)).toEqual([]);
  });

  it("uses shoe sizes 37-42 for shoes and One Size for bags", () => {
    expect(defaultSizes("Shoes")).toEqual(["37", "38", "39", "40", "41", "42"]);
    expect(defaultSizes("Bags")).toEqual(["One Size"]);
    expect(displaySizes({ category: "Bags", sizes: ["S", "M"] })).toEqual(["One Size"]);
  });

  it("filters to shoes only", () => {
    expect(filterProducts([...stock, item("Mule", "Shoes"), item("Tote", "Bags")], "Shoes", "").map((p) => p.name)).toEqual(["Mule"]);
  });
});
