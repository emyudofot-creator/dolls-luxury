import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export const inventoryQuery = queryOptions({
  queryKey: ["admin-inventory"],
  queryFn: async () => {
    const { data, error } = await supabase.rpc("admin_inventory");
    if (error) throw error;
    return data;
  },
});
export const ordersQuery = queryOptions({
  queryKey: ["orders"],
  queryFn: async () => {
    const { data, error } = await supabase.from("orders").select("id,full_name,email,phone,address,items,total,subtotal,delivery_fee,status,stockpile,shipping_state,stock_deducted,created_at,completed_at").order("created_at", { ascending: false });
    if (error) throw error;
    return data;
  },
});
/** Product columns needed to show an ordered item's photo. */
export type ProductImageSource = { id: string; image_url: string | null; images?: string[] | null };

/**
 * Look-up of each product's display photo, keyed by product id.
 * Prefers the first uploaded image, then the legacy single image column.
 * Products with no photo at all (or since deleted) map to null so the UI can show a placeholder.
 */
export const productImageMap = (products: readonly ProductImageSource[]) =>
  new Map<string, string | null>(
    products.map((p) => [p.id, p.images?.find((src) => src.length > 0) ?? p.image_url ?? null]),
  );

export const salesQuery = queryOptions({
  queryKey: ["sales-items"],
  queryFn: async () => {
    const { data, error } = await supabase.from("sales_items").select("id,order_id,product_id,product_name,quantity,unit_price,unit_cost,revenue,created_at");
    if (error) throw error;
    return data;
  },
});