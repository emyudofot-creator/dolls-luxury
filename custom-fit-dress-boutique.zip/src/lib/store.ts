import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import tops from "@/assets/tops.jpg";
import bottoms from "@/assets/bottoms.jpg";
import dresses from "@/assets/dresses.jpg";
import twoPiece from "@/assets/two-piece.jpg";

export const BRAND = "Dolls Luxury";
export const CATEGORIES = ["Tops", "Bottoms", "Dresses", "Two Piece", "Bags", "Shoes"] as const;

export const CLOTHING_SIZES = ["XS", "S", "M", "L", "XL"];
export const SHOE_SIZES = ["37", "38", "39", "40", "41", "42"];
export const ONE_SIZE = "One Size";
/** Default size list for a category: shoe numbers, one size for bags, clothing letters otherwise. */
export const defaultSizes = (category: string) =>
  category === "Shoes" ? SHOE_SIZES : category === "Bags" ? [ONE_SIZE] : CLOTHING_SIZES;
/** Custom measurements only make sense for apparel. */
export const allowsCustomFit = (category: string) => category !== "Shoes" && category !== "Bags";
/** Sizes shown to shoppers; bags always sell as one size. */
export const displaySizes = (p: { category: string; sizes: string[] }) =>
  p.category === "Bags" ? [ONE_SIZE] : p.sizes.length ? p.sizes : defaultSizes(p.category);

export type Product = {
  id: string;
  name: string;
  description: string;
  category: string;
  price: number;
  image_url: string | null;
  images: string[];
  sizes: string[];
  featured: boolean;
  stock_quantity: number;
};

const fallback: Record<string, string> = { Tops: tops, Bottoms: bottoms, Dresses: dresses, "Two Piece": twoPiece, Bags: dresses, Shoes: dresses };
export const productImage = (p: Pick<Product, "image_url" | "category"> & { images?: string[] }) =>
  p.images?.[0] || p.image_url || fallback[p.category] || dresses;
export const productImages = (p: Product) =>
  p.images?.length ? p.images : [productImage(p)];

export const formatPrice = (n: number) =>
  "₦" + Number(n).toLocaleString("en-NG", { maximumFractionDigits: 0 });

export const filterProducts = (products: Product[], category: string, query: string) => {
  const q = query.trim().toLowerCase();
  return products.filter(
    (p) => (category === "All" || p.category === category) && p.name.toLowerCase().includes(q),
  );
};

export const productsQuery = queryOptions({
  queryKey: ["products"],
  queryFn: async () => {
    const { data, error } = await supabase.from("products").select("id,name,description,category,price,image_url,images,sizes,featured,stock_quantity").order("created_at", { ascending: false });
    if (error) throw error;
    return data as Product[];
  },
});

export const productQuery = (id: string) =>
  queryOptions({
    queryKey: ["product", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("products").select("id,name,description,category,price,image_url,images,sizes,featured,stock_quantity").eq("id", id).maybeSingle();
      if (error) throw error;
      return data as Product | null;
    },
  });

export const settingsQuery = queryOptions({
  queryKey: ["settings"],
  queryFn: async () => {
    const { data, error } = await supabase.from("store_settings").select("bank_name,account_number,account_name").eq("id", 1).maybeSingle();
    if (error) throw error;
    return data;
  },
});

export type DeliveryZone = { id: string; name: string; states: string[]; fee: number; sort_order: number };
export const deliveryZonesQuery = queryOptions({
  queryKey: ["delivery-zones"],
  queryFn: async () => {
    const { data, error } = await supabase.from("delivery_zones").select("id,name,states,fee,sort_order").order("sort_order");
    if (error) throw error;
    return data as DeliveryZone[];
  },
});
/** Shipping fee for a state: 0 when stockpiling or no state chosen yet. */
export const deliveryFee = (zones: DeliveryZone[], state: string, stockpile: boolean) =>
  stockpile ? 0 : Number(zones.find((z) => z.states.includes(state))?.fee ?? 0);
