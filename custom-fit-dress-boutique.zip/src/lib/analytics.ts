export type InventoryValue = { cost_price: number; stock_quantity: number };
export type SalesOrder = { id: string; status: string; total: number };
export type SalesLine = { order_id: string; quantity: number; unit_cost: number | null; revenue: number };

export function inventoryAnalytics(products: InventoryValue[], orders: SalesOrder[], lines: SalesLine[]) {
  const completed = new Set(orders.filter((o) => o.status === "Completed").map((o) => o.id));
  const sold = lines.filter((line) => completed.has(line.order_id));
  const costComplete = sold.every((line) => line.unit_cost !== null);
  const revenue = orders.filter((o) => completed.has(o.id)).reduce((sum, o) => sum + Number(o.total), 0);
  const cost = sold.reduce((sum, line) => sum + Number(line.unit_cost ?? 0) * line.quantity, 0);
  return {
    inventoryCost: products.reduce((sum, p) => sum + Number(p.cost_price) * p.stock_quantity, 0),
    revenue,
    cost: costComplete ? cost : null,
    profit: costComplete ? revenue - cost : null,
  };
}