import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { Package, Settings, ShoppingCart, Trash2, Pencil, Plus, LogOut, Upload, X, ShieldCheck } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BRAND, CATEGORIES, defaultSizes, ONE_SIZE, formatPrice, productImage, settingsQuery, deliveryZonesQuery, type Product } from "@/lib/store";
import { toast } from "sonner";
import { AdminMetrics, RecentSales } from "@/components/AdminAnalytics";
import { inventoryQuery, ordersQuery, productImageMap } from "@/lib/admin-data";

export const Route = createFileRoute("/admin")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Admin — Dolls Luxury" },
      { name: "description", content: "Manage Dolls Luxury inventory, orders and payment settings." },
      { property: "og:title", content: "Admin — Dolls Luxury" },
      { property: "og:description", content: "Dolls Luxury store admin." },
      { name: "robots", content: "noindex" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AdminPage,
});

function AdminPage() {
  const nav = useNavigate();
  const [state, setState] = useState<"loading" | "out" | "ok">("loading");
  const [isSuper, setIsSuper] = useState(false);
  useEffect(() => {
    const check = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return setState("out");
      const [{ data }, { data: sup }] = await Promise.all([
        supabase.rpc("has_role", { _user_id: user.id, _role: "admin" }),
        supabase.rpc("is_super_admin", { _user_id: user.id }),
      ]);
      if (!data) {
        toast.error("Access Denied");
        nav({ to: "/", replace: true });
        return;
      }
      setIsSuper(!!sup);
      setState("ok");
    };
    check();
    const { data } = supabase.auth.onAuthStateChange((e) => { if (e === "SIGNED_IN" || e === "SIGNED_OUT") check(); });
    return () => data.subscription.unsubscribe();
  }, [nav]);

  if (state === "loading") return <div className="p-12 text-center text-sm text-muted-foreground">Loading…</div>;
  if (state === "out")
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 px-6 text-center">
        <p className="font-display text-4xl">{BRAND} Admin</p>
        <p className="text-sm text-muted-foreground">Please sign in to continue.</p>
        <Button asChild className="rounded-none"><Link to="/auth">Sign in</Link></Button>
      </div>
    );

  return (
    <div className="min-h-screen">
      <header className="border-b">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-6">
          <Link to="/" className="font-display text-2xl">{BRAND} <span className="eyebrow ml-2">Admin</span></Link>
          <Button variant="ghost" size="sm" onClick={() => supabase.auth.signOut()}><LogOut className="mr-2 h-4 w-4" />Sign out</Button>
        </div>
      </header>
      <main className="mx-auto max-w-7xl px-6 py-10">
        <AdminMetrics />
        <Tabs defaultValue="inventory">
          <TabsList className="rounded-none">
            <TabsTrigger value="inventory" className="rounded-none"><Package className="mr-2 h-4 w-4" />Inventory</TabsTrigger>
            <TabsTrigger value="orders" className="rounded-none"><ShoppingCart className="mr-2 h-4 w-4" />Orders</TabsTrigger>
            <TabsTrigger value="settings" className="rounded-none"><Settings className="mr-2 h-4 w-4" />Settings</TabsTrigger>
            {isSuper && <TabsTrigger value="admins" className="rounded-none"><ShieldCheck className="mr-2 h-4 w-4" />Admin Management</TabsTrigger>}
          </TabsList>
          <TabsContent value="inventory" className="mt-8"><Inventory /></TabsContent>
          <TabsContent value="orders" className="mt-8"><Orders /></TabsContent>
          <TabsContent value="settings" className="mt-8"><SettingsTab /></TabsContent>
          {isSuper && <TabsContent value="admins" className="mt-8"><AdminManagement /></TabsContent>}
        </Tabs>
        <RecentSales />
      </main>
    </div>
  );
}

const empty = { name: "", description: "", category: "Tops", price: "", cost_price: "0", stock_quantity: "0", sizes: "XS, S, M, L, XL", featured: false, images: [] as string[] };
type Pending = { file: File; preview: string };

function Inventory() {
  const qc = useQueryClient();
  const { data: products = [], isError } = useQuery(inventoryQuery);
  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [f, setF] = useState(empty);
  const [files, setFiles] = useState<Pending[]>([]);
  const [busy, setBusy] = useState(false);

  const start = (p?: Product & { cost_price: number }) => {
    setEditId(p?.id ?? null);
    const imgs = p ? (p.images?.length ? p.images : p.image_url ? [p.image_url] : []) : [];
    setF(p ? { name: p.name, description: p.description, category: p.category, price: String(p.price), cost_price: String(p.cost_price), stock_quantity: String(p.stock_quantity), sizes: p.sizes.join(", "), featured: p.featured, images: imgs } : empty);
    files.forEach((x) => URL.revokeObjectURL(x.preview));
    setFiles([]);
    setOpen(true);
  };

  const addFiles = (list: FileList | null) => {
    if (!list) return;
    const ok: Pending[] = [];
    for (const file of Array.from(list)) {
      if (!file.type.startsWith("image/")) continue;
      if (file.size > 5 * 1024 * 1024) { toast.error(`${file.name} is over 5MB`); continue; }
      ok.push({ file, preview: URL.createObjectURL(file) });
    }
    setFiles((prev) => [...prev, ...ok].slice(0, 20));
  };

  const save = async () => {
    const price = Number(f.price);
    const cost_price = Number(f.cost_price);
    const stock_quantity = Number(f.stock_quantity);
    if (!f.name.trim() || f.name.length > 120) { toast.error("Enter a name"); return; }
    if (!f.price.trim() || !Number.isFinite(price) || price < 0) { toast.error("Enter a valid price"); return; }
    if (!f.cost_price.trim() || !Number.isFinite(cost_price) || cost_price < 0) { toast.error("Enter a valid cost price"); return; }
    if (!f.stock_quantity.trim() || !Number.isInteger(stock_quantity) || stock_quantity < 0 || stock_quantity > 2147483647) { toast.error("Enter a whole stock quantity of zero or more"); return; }
    setBusy(true);
    const uploaded: string[] = [];
    for (const { file } of files) {
      const path = `${crypto.randomUUID()}.${file.name.split(".").pop()}`;
      const up = await supabase.storage.from("product-images").upload(path, file);
      if (up.error) { setBusy(false); toast.error(`Upload failed: ${file.name}`); return; }
      const signed = await supabase.storage.from("product-images").createSignedUrl(path, 60 * 60 * 24 * 365 * 10);
      if (signed.data?.signedUrl) uploaded.push(signed.data.signedUrl);
    }
    const images = [...f.images, ...uploaded];
    const row = {
      name: f.name.trim(), description: f.description.trim().slice(0, 2000), category: f.category, price,
      sizes: f.category === "Bags" ? [ONE_SIZE] : f.sizes.split(",").map((s) => s.trim()).filter(Boolean).slice(0, 12), featured: f.featured,
      images, image_url: images[0] ?? null,
      cost_price, stock_quantity,
    };
    const { error } = editId ? await supabase.from("products").update(row).eq("id", editId) : await supabase.from("products").insert(row);
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Saved");
    setOpen(false);
    qc.invalidateQueries({ queryKey: ["products"] });
    qc.invalidateQueries({ queryKey: ["product"] });
    qc.invalidateQueries({ queryKey: ["admin-inventory"] });
  };

  const del = async (id: string) => {
    if (!confirm("Delete this item?")) return;
    const { error } = await supabase.from("products").delete().eq("id", id);
    if (error) { toast.error(error.message); return; }
    qc.invalidateQueries({ queryKey: ["products"] });
    qc.invalidateQueries({ queryKey: ["admin-inventory"] });
  };

  return (
    <div>
      <div className="flex items-center justify-between">
        <h2 className="text-3xl">Inventory</h2>
        <Button onClick={() => start()} className="rounded-none"><Plus className="mr-2 h-4 w-4" />Add outfit</Button>
      </div>
      <div className="mt-6 divide-y border">
        {isError && <p role="alert" className="p-4 text-destructive">Unable to load inventory.</p>}
        {products.map((p) => (
          <div key={p.id} className="grid grid-cols-[48px_minmax(0,1fr)_40px_40px] items-center gap-3 p-4 sm:flex">
            <img src={productImage(p)} alt={p.name} loading="lazy" decoding="async" width={48} height={64} className="h-16 w-12 object-cover" />
            <div className="col-span-3 min-w-0 flex-1">
              <p className="font-medium">{p.name} {p.featured && <span className="eyebrow ml-2 text-blush">Featured</span>}</p>
              <p className="text-xs text-muted-foreground">{p.category} · {p.sizes.join(", ")}</p>
              <p className="mt-1 text-xs text-muted-foreground">Stock: {p.stock_quantity} · Cost: {formatPrice(p.cost_price)}</p>
            </div>
            <p className="col-span-2 text-sm sm:w-28 sm:text-right">{formatPrice(p.price)}</p>
            <Button variant="ghost" size="icon" onClick={() => start(p)} aria-label="Edit"><Pencil className="h-4 w-4" /></Button>
            <Button variant="ghost" size="icon" onClick={() => del(p.id)} aria-label="Delete"><Trash2 className="h-4 w-4 text-destructive" /></Button>
          </div>
        ))}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto rounded-none">
          <DialogHeader><DialogTitle className="font-display text-2xl font-normal">{editId ? "Edit outfit" : "New outfit"}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2"><Label>Name</Label><Input value={f.name} maxLength={120} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
            <div className="space-y-2"><Label>Description</Label><Textarea value={f.description} maxLength={2000} onChange={(e) => setF({ ...f, description: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2"><Label>Category</Label>
                <Select value={f.category} onValueChange={(v) => setF({ ...f, category: v, sizes: defaultSizes(v).join(", ") })}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2"><Label>Price (₦)</Label><Input type="number" min={0} value={f.price} onChange={(e) => setF({ ...f, price: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2"><Label htmlFor="cost_price">Cost Price (₦)</Label><Input id="cost_price" type="number" min={0} step="0.01" value={f.cost_price} onChange={(e) => setF({ ...f, cost_price: e.target.value })} /></div>
              <div className="space-y-2"><Label htmlFor="stock_quantity">Current Stock Quantity</Label><Input id="stock_quantity" type="number" min={0} step={1} value={f.stock_quantity} onChange={(e) => setF({ ...f, stock_quantity: e.target.value })} /></div>
            </div>
            {f.category === "Bags" ? (
              <div className="space-y-2"><Label>Size</Label><p className="text-sm text-muted-foreground">One Size</p></div>
            ) : (
              <div className="space-y-2"><Label>{f.category === "Shoes" ? "Shoe sizes (comma separated)" : "Sizes (comma separated)"}</Label><Input value={f.sizes} onChange={(e) => setF({ ...f, sizes: e.target.value })} /></div>
            )}
            <div className="space-y-2">
              <Label>Images</Label>
              <label className="flex cursor-pointer items-center gap-3 border border-dashed p-4 text-sm text-muted-foreground">
                <Upload className="h-4 w-4" />Upload images (select several at once)
                <input type="file" accept="image/*" multiple className="hidden" onChange={(e) => { addFiles(e.target.files); e.target.value = ""; }} />
              </label>
              {(f.images.length > 0 || files.length > 0) && (
                <div className="grid grid-cols-4 gap-2">
                  {f.images.map((src, i) => (
                    <div key={src} className="relative">
                      <img src={src} alt="" loading="lazy" decoding="async" className="aspect-[3/4] w-full object-cover" />
                      {i === 0 && <span className="absolute left-1 top-1 bg-background px-1 text-[10px] uppercase">Main</span>}
                      <button type="button" aria-label="Remove image" onClick={() => setF({ ...f, images: f.images.filter((x) => x !== src) })}
                        className="absolute right-1 top-1 bg-background p-1"><X className="h-3 w-3" /></button>
                    </div>
                  ))}
                  {files.map((p) => (
                    <div key={p.preview} className="relative opacity-80">
                      <img src={p.preview} alt="" className="aspect-[3/4] w-full object-cover" />
                      <span className="absolute bottom-1 left-1 bg-background px-1 text-[10px] uppercase">New</span>
                      <button type="button" aria-label="Remove image" onClick={() => { URL.revokeObjectURL(p.preview); setFiles(files.filter((x) => x !== p)); }}
                        className="absolute right-1 top-1 bg-background p-1"><X className="h-3 w-3" /></button>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="flex items-center gap-3"><Switch checked={f.featured} onCheckedChange={(v) => setF({ ...f, featured: v })} /><Label>Feature on home page</Label></div>
            <Button onClick={save} disabled={busy} className="w-full rounded-none">{busy ? "Saving…" : "Save"}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

type OrderItem = { product_id: string; name: string; price: number; quantity: number; size: string; measurements: string };
const STATUSES = ["Pending Payment", "Pending", "Processing", "Completed"] as const;

/** 48px product photo for an ordered item; a neutral box icon when the product has no image. */
function ItemThumb({ src, name }: { src: string | null | undefined; name: string }) {
  return src ? (
    <img src={src} alt={name} loading="lazy" decoding="async" width={48} height={48} className="h-12 w-12 shrink-0 rounded-[6px] bg-secondary object-cover" />
  ) : (
    <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-[6px] bg-secondary text-muted-foreground" title="No photo">
      <Package aria-hidden className="h-5 w-5" strokeWidth={1.5} />
      <span className="sr-only">No photo</span>
    </span>
  );
}

function Orders() {
  const qc = useQueryClient();
  const { data: orders = [] } = useQuery(ordersQuery);
  const { data: inventory = [] } = useQuery(inventoryQuery);
  const stockOf = new Map(inventory.map((p) => [p.id, p.stock_quantity]));
  const imageOf = productImageMap(inventory);
  const unavailable = (o: (typeof orders)[number]) =>
    o.stock_deducted ? [] : (o.items as unknown as OrderItem[]).filter((i) => (stockOf.get(i.product_id) ?? 0) < i.quantity).map((i) => i.name);
  const setStatus = async (id: string, status: (typeof STATUSES)[number]) => {
    const { error } = await supabase.from("orders").update({ status }).eq("id", id);
    if (error) { toast.error(error.message); return; }
    qc.invalidateQueries({ queryKey: ["orders"] });
    qc.invalidateQueries({ queryKey: ["sales-items"] });
    for (const key of ["admin-inventory", "products", "product"]) qc.invalidateQueries({ queryKey: [key] });
  };
  return (
    <div>
      <h2 className="text-3xl">Orders</h2>
      {orders.length === 0 && <p className="mt-6 text-sm text-muted-foreground">No orders yet.</p>}
      <div className="mt-6 space-y-4">
        {orders.map((o) => (
          <div key={o.id} className="border p-5">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <p className="font-medium">{o.full_name} <span className="eyebrow ml-2">#{o.id.slice(0, 8)}</span></p>
                <p className="text-xs text-muted-foreground">{o.email} · {o.phone}</p>
                <p className="text-xs text-muted-foreground">{o.address}</p>
                <p className="text-xs">{o.stockpile ? <span className="font-medium">Stockpile: True — hold for later shipping</span> : <>Ship to {o.shipping_state ?? "—"} · Delivery {formatPrice(o.delivery_fee)}</>}</p>
                <p className="text-xs text-muted-foreground">{new Date(o.created_at).toLocaleString()}</p>
              </div>
              <div className="flex items-center gap-4">
                <p className="text-lg">{formatPrice(o.total)}</p>
                <Select value={o.status} onValueChange={(v) => setStatus(o.id, v as (typeof STATUSES)[number])}>
                  <SelectTrigger className="w-44 rounded-none"><SelectValue /></SelectTrigger>
                  <SelectContent>{STATUSES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </div>
            {unavailable(o).length > 0 && (
              <p className="mt-3 border border-destructive bg-destructive/10 p-3 text-xs text-destructive">
                No longer available: {unavailable(o).join(", ")} sold out before this order was approved. Contact the customer before approving.
              </p>
            )}
            <ul className="mt-4 space-y-2 border-t pt-3 text-sm">
              {(o.items as unknown as OrderItem[]).map((i, idx) => (
                <li key={idx} className="flex items-center justify-between gap-4">
                  <span className="flex min-w-0 items-center gap-3">
                    <ItemThumb src={imageOf.get(i.product_id)} name={i.name} />
                    <span className="min-w-0">{i.name} — {i.size} × {i.quantity}{i.measurements && <span className="block text-xs text-muted-foreground">Measurements: {i.measurements}</span>}</span>
                  </span>
                  <span className="shrink-0">{formatPrice(i.price * i.quantity)}</span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}

function SettingsTab() {
  const qc = useQueryClient();
  const { data } = useQuery(settingsQuery);
  const [f, setF] = useState({ bank_name: "", account_number: "", account_name: "" });
  useEffect(() => { if (data) setF({ bank_name: data.bank_name, account_number: data.account_number, account_name: data.account_name }); }, [data]);
  const save = async () => {
    const clean = { bank_name: f.bank_name.trim().slice(0, 100), account_number: f.account_number.trim().slice(0, 40), account_name: f.account_name.trim().slice(0, 120) };
    const { error } = await supabase.from("store_settings").update({ ...clean, updated_at: new Date().toISOString() }).eq("id", 1);
    if (error) { toast.error(error.message); return; }
    toast.success("Payment details updated");
    qc.invalidateQueries({ queryKey: ["settings"] });
  };
  return (
    <div className="max-w-lg">
      <h2 className="text-3xl">Payment details</h2>
      <p className="mt-2 text-sm text-muted-foreground">Shown to customers on the checkout page.</p>
      <div className="mt-6 space-y-4">
        <div className="space-y-2"><Label>Bank name</Label><Input value={f.bank_name} onChange={(e) => setF({ ...f, bank_name: e.target.value })} /></div>
        <div className="space-y-2"><Label>Account number</Label><Input value={f.account_number} onChange={(e) => setF({ ...f, account_number: e.target.value })} /></div>
        <div className="space-y-2"><Label>Account holder name</Label><Input value={f.account_name} onChange={(e) => setF({ ...f, account_name: e.target.value })} /></div>
        <Button onClick={save} className="rounded-none">Save details</Button>
      </div>
      <DeliveryFees />
    </div>
  );
}

function DeliveryFees() {
  const qc = useQueryClient();
  const { data: zones = [] } = useQuery(deliveryZonesQuery);
  const [fees, setFees] = useState<Record<string, string>>({});
  useEffect(() => { setFees(Object.fromEntries(zones.map((z) => [z.id, String(z.fee)]))); }, [zones]);
  const save = async (id: string) => {
    const fee = Number(fees[id]);
    if (!Number.isFinite(fee) || fee < 0) { toast.error("Enter a valid fee"); return; }
    const { error } = await supabase.from("delivery_zones").update({ fee, updated_at: new Date().toISOString() }).eq("id", id);
    if (error) { toast.error(error.message); return; }
    toast.success("Delivery fee updated");
    qc.invalidateQueries({ queryKey: ["delivery-zones"] });
  };
  return (
    <div className="mt-12">
      <h2 className="text-3xl">Delivery Fee Management</h2>
      <p className="mt-2 text-sm text-muted-foreground">Flat delivery price per region, added at checkout.</p>
      <table className="mt-6 w-full text-left text-sm">
        <thead className="border-b text-muted-foreground"><tr><th className="py-3 pr-4 font-normal">Region</th><th className="py-3 pr-4 font-normal">Fee (₦)</th><th /></tr></thead>
        <tbody>{zones.map((z) => (
          <tr key={z.id} className="border-b align-top">
            <td className="py-3 pr-4"><p>{z.name}</p><p className="text-xs text-muted-foreground">{z.states.join(", ")}</p></td>
            <td className="py-3 pr-4"><Input type="number" min={0} aria-label={`${z.name} fee`} value={fees[z.id] ?? ""} onChange={(e) => setFees({ ...fees, [z.id]: e.target.value })} className="w-28 rounded-none" /></td>
            <td className="py-3"><Button size="sm" variant="outline" className="rounded-none" onClick={() => save(z.id)}>Save</Button></td>
          </tr>
        ))}</tbody>
      </table>
    </div>
  );
}

function AdminManagement() {
  const qc = useQueryClient();
  const { data: admins = [], isError } = useQuery({
    queryKey: ["admins"],
    queryFn: async () => {
      const { data, error } = await supabase.rpc("list_admins");
      if (error) throw error;
      return data;
    },
  });
  const [email, setEmail] = useState("");
  const add = async () => {
    if (!email.trim()) { toast.error("Enter an email"); return; }
    const { error } = await supabase.rpc("add_admin", { _email: email.trim() });
    if (error) { toast.error(error.message); return; }
    toast.success("Admin added");
    setEmail("");
    qc.invalidateQueries({ queryKey: ["admins"] });
  };
  const remove = async (id: string) => {
    if (!confirm("Remove this admin?")) return;
    const { error } = await supabase.rpc("remove_admin", { _user_id: id });
    if (error) { toast.error(error.message); return; }
    toast.success("Admin removed");
    qc.invalidateQueries({ queryKey: ["admins"] });
  };
  return (
    <div className="max-w-lg">
      <h2 className="text-3xl">Admin Management</h2>
      <p className="mt-2 text-sm text-muted-foreground">Only the Super Admin can add or remove admins. The person must already have an account.</p>
      <div className="mt-6 flex gap-2">
        <Input type="email" placeholder="email@example.com" value={email} onChange={(e) => setEmail(e.target.value)} className="rounded-none" aria-label="New admin email" />
        <Button onClick={add} className="rounded-none"><Plus className="mr-2 h-4 w-4" />Add admin</Button>
      </div>
      {isError && <p role="alert" className="mt-4 text-destructive">Unable to load admins.</p>}
      <div className="mt-6 divide-y border">
        {admins.map((a) => (
          <div key={a.user_id} className="flex items-center justify-between p-4">
            <p className="text-sm">{a.email} {a.is_super && <span className="eyebrow ml-2 text-blush">Super Admin</span>}</p>
            {!a.is_super && <Button variant="ghost" size="icon" aria-label={`Remove ${a.email}`} onClick={() => remove(a.user_id)}><Trash2 className="h-4 w-4 text-destructive" /></Button>}
          </div>
        ))}
      </div>
    </div>
  );
}
