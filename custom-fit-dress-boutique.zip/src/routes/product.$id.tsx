import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { ArrowLeft, ChevronLeft, ChevronRight, Ruler } from "lucide-react";
import { SiteHeader, SiteFooter } from "@/components/SiteHeader";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useCart } from "@/lib/cart";
import { Skeleton } from "@/components/ui/skeleton";
import { allowsCustomFit, displaySizes, formatPrice, productImage, productImages, productQuery, productsQuery, type Product } from "@/lib/store";

function Gallery({ images, name }: { images: string[]; name: string }) {
  const [i, setI] = useState(0);
  const n = images.length;
  const go = (d: number) => setI((x) => (x + d + n) % n);
  return (
    <div>
      <div className="relative">
        <img src={images[i]} alt={`${name} ${i + 1}`} fetchPriority={i === 0 ? "high" : "auto"} decoding="async" className="aspect-[3/4] w-full bg-muted object-cover" />
        {n > 1 && (
          <>
            <button aria-label="Previous image" onClick={() => go(-1)} className="absolute left-3 top-1/2 -translate-y-1/2 bg-background/80 p-2 hover:bg-background"><ChevronLeft className="h-5 w-5" /></button>
            <button aria-label="Next image" onClick={() => go(1)} className="absolute right-3 top-1/2 -translate-y-1/2 bg-background/80 p-2 hover:bg-background"><ChevronRight className="h-5 w-5" /></button>
            <span className="absolute bottom-3 right-3 bg-background/80 px-2 py-1 text-xs">{i + 1} / {n}</span>
          </>
        )}
      </div>
      {n > 1 && (
        <div className="mt-3 grid grid-cols-5 gap-2">
          {images.map((src, idx) => (
            <button key={src + idx} onClick={() => setI(idx)} aria-label={`Show image ${idx + 1}`}
              className={`border transition ${idx === i ? "border-foreground" : "border-transparent opacity-60 hover:opacity-100"}`}>
              <img src={src} alt="" loading="lazy" decoding="async" className="aspect-[3/4] w-full object-cover" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
import { toast } from "sonner";

export const Route = createFileRoute("/product/$id")({
  loader: async ({ context, params }) => {
    // Reuse the catalog's cached copy so opening a product from the shop is instant.
    const q = productQuery(params.id);
    if (!context.queryClient.getQueryData(q.queryKey)) {
      const cached = context.queryClient.getQueryData<Product[]>(productsQuery.queryKey)?.find((x) => x.id === params.id);
      if (cached) context.queryClient.setQueryData(q.queryKey, cached);
    }
    const p = await context.queryClient.ensureQueryData(q);
    if (!p) throw notFound();
    return p;
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: loaderData ? `${loaderData.name} — Dolls Luxury` : "Dolls Luxury" },
      { name: "description", content: loaderData?.description || "Shop Dolls Luxury." },
      { property: "og:title", content: loaderData ? `${loaderData.name} — Dolls Luxury` : "Dolls Luxury" },
      { property: "og:description", content: loaderData?.description || "Shop Dolls Luxury." },
      { property: "og:type", content: "product" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ProductPage,
  pendingMs: 150,
  pendingComponent: () => (
    <div className="min-h-screen">
      <SiteHeader />
      <div className="mx-auto grid max-w-7xl gap-12 px-6 py-10 md:grid-cols-2">
        <Skeleton className="aspect-[3/4] w-full rounded-none" />
        <div className="space-y-4"><Skeleton className="h-10 w-2/3" /><Skeleton className="h-6 w-24" /><Skeleton className="h-24 w-full" /><Skeleton className="h-12 w-full" /></div>
      </div>
    </div>
  ),
});

function ProductPage() {
  const { id } = Route.useParams();
  const { data: p } = useSuspenseQuery(productQuery(id));
  const { add } = useCart();
  const [size, setSize] = useState<string>("");
  const [custom, setCustom] = useState(false);
  const [measure, setMeasure] = useState("");
  if (!p) return null;
  const sizes = displaySizes(p);
  const fit = allowsCustomFit(p.category);

  const onAdd = () => {
    if (p.stock_quantity <= 0) { toast.error("This outfit is out of stock"); return; }
    const chosen = size || (sizes.length === 1 ? sizes[0] ?? "" : "");
    if (!custom && !chosen) { toast.error("Please select a size"); return; }
    if (custom && measure.trim().length < 3) { toast.error("Please enter your measurements"); return; }
    add({ product_id: p.id, name: p.name, price: Number(p.price), image: productImage(p), size: custom ? "Custom" : chosen, measurements: custom ? measure.trim().slice(0, 500) : "" });
  };

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <div className="mx-auto max-w-7xl px-6 py-10">
        <Link to="/" className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-muted-foreground hover:text-foreground"><ArrowLeft className="h-4 w-4" /> Back</Link>
        <div className="mt-8 grid gap-12 md:grid-cols-2">
          <Gallery images={productImages(p)} name={p.name} />
          <div className="md:py-8">
            <p className="eyebrow">{p.category}</p>
            <h1 className="mt-3 text-5xl">{p.name}</h1>
            <p className="mt-4 text-xl">{formatPrice(p.price)}</p>
            <p className="mt-6 leading-relaxed text-muted-foreground">{p.description}</p>

            <div className="mt-10">
              <p className="eyebrow mb-3">{p.category === "Shoes" ? "Select shoe size" : "Select size"}</p>
              <div className="flex flex-wrap gap-2">
                {sizes.map((s) => (
                  <button key={s} onClick={() => { setSize(s); setCustom(false); }}
                    className={`h-11 min-w-11 border px-3 text-sm transition ${!custom && size === s ? "border-foreground bg-foreground text-background" : "hover:border-foreground"}`}>{s}</button>
                ))}
                {fit && <button onClick={() => setCustom(true)}
                  className={`flex h-11 items-center gap-2 border px-4 text-sm transition ${custom ? "border-foreground bg-foreground text-background" : "hover:border-foreground"}`}>
                  <Ruler className="h-4 w-4" /> Custom fit
                </button>}
              </div>
              {custom && (
                <Textarea value={measure} onChange={(e) => setMeasure(e.target.value)} maxLength={500} rows={4} className="mt-4 rounded-none"
                  placeholder="e.g. Bust 36in, Waist 28in, Hips 40in, Length 50in" />
              )}
            </div>
            <Button onClick={onAdd} disabled={p.stock_quantity <= 0} size="lg" className="mt-8 h-14 w-full rounded-none text-xs uppercase tracking-[0.25em]">{p.stock_quantity <= 0 ? "Out of stock" : "Add to bag"}</Button>
          </div>
        </div>
      </div>
      <SiteFooter />
    </div>
  );
}
