import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { z } from "zod";
import { CheckCircle2, Landmark } from "lucide-react";
import { SiteHeader, SiteFooter } from "@/components/SiteHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useCart } from "@/lib/cart";
import { formatPrice, settingsQuery, deliveryZonesQuery, deliveryFee } from "@/lib/store";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const Route = createFileRoute("/checkout")({
  head: () => ({
    meta: [
      { title: "Checkout — Dolls Luxury" },
      { name: "description", content: "Complete your Dolls Luxury order with a simple bank transfer." },
      { property: "og:title", content: "Checkout — Dolls Luxury" },
      { property: "og:description", content: "Complete your Dolls Luxury order." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Checkout,
});

const schema = z.object({
  full_name: z.string().trim().min(2, "Enter your full name").max(120),
  address: z.string().trim().min(5, "Enter a delivery address").max(500),
  phone: z.string().trim().min(7, "Enter a valid phone number").max(30).regex(/^[+\d\s()-]+$/, "Enter a valid phone number"),
  email: z.string().trim().email("Enter a valid email").max(255),
});

function Checkout() {
  const qc = useQueryClient();
  const { items, total, clear } = useCart();
  const { data: bank } = useQuery(settingsQuery);
  const [form, setForm] = useState({ full_name: "", address: "", phone: "", email: "" });
  const { data: zones = [] } = useQuery(deliveryZonesQuery);
  const [stockpile, setStockpile] = useState(false);
  const [state, setState] = useState("");
  const shipping = deliveryFee(zones, state, stockpile);
  const grand = total + shipping;
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<{ id: string; total: number } | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const r = schema.safeParse(form);
    if (!r.success) { toast.error(r.error.issues[0]?.message ?? "Invalid input"); return; }
    if (!items.length) { toast.error("Your bag is empty"); return; }
    if (!stockpile && !state) { toast.error("Select your delivery state"); return; }
    setBusy(true);
    const { data, error } = await supabase.rpc("place_order", {
      _full_name: r.data.full_name, _email: r.data.email, _phone: r.data.phone, _address: r.data.address,
      _items: items.map((i) => ({ product_id: i.product_id, quantity: i.quantity, size: i.size, measurements: i.measurements })),
      _stockpile: stockpile, _state: stockpile ? "" : state,
    });
    setBusy(false);
    if (error) { toast.error((error.message.startsWith("Insufficient stock") || error.message.startsWith("Please select")) ? error.message : "Could not place order. Please try again."); return; }
    for (const key of ["products", "product", "admin-inventory", "orders", "sales-items"]) qc.invalidateQueries({ queryKey: [key] });
    setDone({ id: data as string, total: grand });
    clear();
  };

  const BankBox = (
    <div className="border bg-card p-6">
      <div className="flex items-center gap-2"><Landmark className="h-4 w-4" strokeWidth={1.5} /><p className="eyebrow text-foreground">Pay by bank transfer</p></div>
      <dl className="mt-4 space-y-2 text-sm">
        <div className="flex justify-between"><dt className="text-muted-foreground">Bank</dt><dd>{bank?.bank_name || "—"}</dd></div>
        <div className="flex justify-between"><dt className="text-muted-foreground">Account number</dt><dd className="font-medium tracking-wider">{bank?.account_number || "—"}</dd></div>
        <div className="flex justify-between"><dt className="text-muted-foreground">Account name</dt><dd>{bank?.account_name || "—"}</dd></div>
      </dl>
      <p className="mt-4 text-xs text-muted-foreground">Use your full name as the transfer reference. We'll confirm your order once payment arrives.</p>
    </div>
  );

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <div className="mx-auto max-w-6xl px-6 py-12">
        {done ? (
          <div className="mx-auto max-w-lg text-center">
            <CheckCircle2 className="mx-auto h-12 w-12 text-success" strokeWidth={1.2} />
            <h1 className="mt-6 text-5xl">Thank you.</h1>
            <p className="mt-4 text-muted-foreground">Your order is placed and awaiting payment. Please transfer <strong className="text-foreground">{formatPrice(done.total)}</strong> to the account below.</p>
            <p className="eyebrow mt-2">Order #{done.id.slice(0, 8)}</p>
            <div className="mt-8 text-left">{BankBox}</div>
            <Link to="/" className="mt-8 inline-block text-xs uppercase tracking-[0.2em] underline">Continue shopping</Link>
          </div>
        ) : (
          <>
            <h1 className="text-5xl">Checkout</h1>
            <form onSubmit={submit} className="mt-10 grid gap-12 md:grid-cols-[1fr_420px]">
              <div className="space-y-5">
                <p className="eyebrow">Your details</p>
                {([
                  ["full_name", "Full name", "text"],
                  ["email", "Email", "email"],
                  ["phone", "Phone number", "tel"],
                ] as const).map(([k, l, t]) => (
                  <div key={k} className="space-y-2">
                    <Label htmlFor={k}>{l}</Label>
                    <Input id={k} type={t} value={form[k]} onChange={(e) => setForm({ ...form, [k]: e.target.value })} className="h-12 rounded-none" required />
                  </div>
                ))}
                <div className="space-y-2">
                  <Label htmlFor="address">Delivery address</Label>
                  <Textarea id="address" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} rows={3} maxLength={500} className="rounded-none" required />
                </div>
                <p className="eyebrow pt-4">Delivery</p>
                <div className="flex items-start gap-3">
                  <Checkbox id="stockpile" checked={stockpile} onCheckedChange={(v) => setStockpile(v === true)} className="mt-0.5" />
                  <Label htmlFor="stockpile" className="leading-snug">Stockpile my items? (Hold my order to ship later with future orders)</Label>
                </div>
                {stockpile ? (
                  <p className="border bg-secondary p-4 text-sm">Your items will be safely stored. Shipping will be paid when you are ready to ship all your stockpiled orders.</p>
                ) : (
                  <div className="space-y-2">
                    <Label htmlFor="state">State</Label>
                    <Select value={state} onValueChange={setState}>
                      <SelectTrigger id="state" className="h-12 rounded-none"><SelectValue placeholder="Select your state" /></SelectTrigger>
                      <SelectContent>
                        {zones.map((z) => (
                          <SelectGroup key={z.id}>
                            <SelectLabel>{z.name} — {formatPrice(z.fee)}</SelectLabel>
                            {z.states.map((st) => <SelectItem key={st} value={st}>{st}</SelectItem>)}
                          </SelectGroup>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>
              <div className="space-y-6">
                <div className="bg-secondary p-6">
                  <p className="eyebrow text-foreground">Order summary</p>
                  <div className="mt-4 space-y-4">
                    {items.length === 0 && <p className="text-sm text-muted-foreground">Your bag is empty.</p>}
                    {items.map((i) => (
                      <div key={i.key} className="flex gap-3 text-sm">
                        <img src={i.image} alt={i.name} loading="lazy" decoding="async" width={48} height={64} className="h-16 w-12 object-cover" />
                        <div className="flex-1">
                          <p>{i.name}</p>
                          <p className="text-xs text-muted-foreground">{i.size} × {i.quantity}</p>
                        </div>
                        <p>{formatPrice(i.price * i.quantity)}</p>
                      </div>
                    ))}
                  </div>
                  <div className="mt-6 space-y-2 border-t pt-4 text-sm">
                    <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span>{formatPrice(total)}</span></div>
                    <div className="flex justify-between"><span className="text-muted-foreground">Shipping fee</span><span>{stockpile ? "₦0 (stockpiled)" : state ? formatPrice(shipping) : "Select a state"}</span></div>
                    <div className="flex justify-between border-t pt-2 uppercase tracking-widest"><span>Final total</span><span>{formatPrice(grand)}</span></div>
                  </div>
                </div>
                {BankBox}
                <Button type="submit" disabled={busy || !items.length} size="lg" className="h-14 w-full rounded-none text-xs uppercase tracking-[0.25em]">
                  {busy ? "Placing order…" : "Place order"}
                </Button>
              </div>
            </form>
          </>
        )}
      </div>
      <SiteFooter />
    </div>
  );
}
